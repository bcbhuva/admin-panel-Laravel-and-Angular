'use strict'

angular.module('apiClientApp')
  .controller('LoginCtrl', function(authUser){
    var vm = this;
    vm.loginForm = {
      email: 'kevin@gmail.com',
      password: '123456789'
    };
    vm.login = function () {
      authUser.loginApi(vm.loginForm);
    }
  });
