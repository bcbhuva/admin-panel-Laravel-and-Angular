'use strict';

/**
 * @ngdoc function
 * @name apiClientApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the apiClientApp
 */
angular.module('apiClientApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
